export const STATUS_APPT_CANCEL = 2;
