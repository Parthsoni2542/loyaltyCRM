import { useAsyncStorage } from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { build, version } from '../../../package.json';
import colors from '../../assets/theme/colors';
import { USER } from '../../constants/prefrenceKeys';
import {
  CHANGE_PASSWORD,
  EDIT_PROFILE,
  PROFILE,
} from '../../constants/routeName';
import Container from '../common/Container';
import Toolbar from '../common/Toolbar';
import styles from './styles';
import Barcode from "react-native-barcode-builder";
import { GlobalContext } from '../../context/Provider';
import { useContext } from 'react';
import moment from 'moment';

const ProfileComponent = ({ logoutClick, profiledata }) => {

  
  const { navigate } = useNavigation();

  const [user, setUser] = useState("");
  const { getItem } = useAsyncStorage(USER);
  const {systemConfigState} = useContext(GlobalContext);
  console.log("systemConfigState",systemConfigState)
  useEffect(async () => {
    let isCancelled = false;
    const usr = JSON.parse(await getItem());

    if (!isCancelled) {
      setUser(usr);
    }
    return () => {
      isCancelled = true;
    };
  }, []);

  return (
    <Container>
      {
        systemConfigState.data.customer_info_allow_customer_to_edit_profile == 1 ? <Toolbar
        title={PROFILE}
        hideBackBtn
        rightOptionMenu={
          <TouchableOpacity
            onPress={() => {
              navigate(EDIT_PROFILE);
            }}>
            <Image source={require('../../assets/images/ic_edit.png')} />
          </TouchableOpacity>
        }
      />:<Toolbar
      title={PROFILE}
      hideBackBtn
      
    />
      }
      
      <ScrollView>
        {
          profiledata.data.length == 0 ? <View></View> :
            <View style={styles.topWrapper}>
              <View style={styles.proflieWrapper}>
                <Image
                  style={{ height: 180, width: 180, borderRadius: 90 }}
                  source={
                    profiledata.data?.image?.length > 0
                      ? { uri: profiledata.data.image }
                      : require('../../assets/images/img_profile_big.png')
                  }
                  PlaceholderContent={<ActivityIndicator />}
                />
                <Text style={styles.profileName}>
                   {profiledata.data.first_name==null?"": profiledata.data.first_name} {profiledata.data.last_name==null?" ":  profiledata.data.last_name}
                  {/* {profiledata.data.first_name + ' ' + profiledata.data.last_name} */}
                </Text>
              </View>
              <View style={styles.detailWrapper}>
                
                <Text style={styles.lable}>Email</Text>
                <TextInput
                  style={styles.value}
                  value={profiledata.data.email}
                  editable={false}
                />
                <Text style={styles.lable}>Phone Number</Text>
                <TextInput
                  style={styles.value}
                  value={profiledata.data.phone_number}
                  editable={false}
                />
                {
                  profiledata.data.birthdate == null ||profiledata.data.birthdate=="0000-00-00" ?<View></View>:
                  <View>
                 <Text style={styles.lable}>Birth Date</Text>
                <TextInput
                  style={styles.value}
                  value={moment(profiledata.data.birthdate).format('DD-MM-YYYY')}
                  editable={false}
                 
                />
                 </View>
              }
                <TouchableOpacity
                  onPress={() => {
                    navigate(CHANGE_PASSWORD);
                  }}>
                  <Text style={styles.changePassword}>Change Password</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => { logoutClick() }}>
                  <Text style={styles.logout}>Logout</Text>
                </TouchableOpacity>
                <Text
                  style={{ fontSize: 12, color: colors.grey, alignSelf: 'flex-end' }}>
                  Version:{version}.{build} (111122)
                </Text>

                <Barcode value={profiledata.data == "" ? "0" : profiledata.data.membership_code} format="CODE128" width={2} height={50} text={profiledata.data == "" ? "0" : profiledata.data.membership_code} />
              </View>
            </View>
        }
      </ScrollView>
    </Container>
  );
};

export default ProfileComponent;
