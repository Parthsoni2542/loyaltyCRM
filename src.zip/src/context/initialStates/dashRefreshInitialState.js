export default dashRefreshInitialState = {
  needRefresh: false,
};
