export default {
  data: {
    hasMore: 1,
    pageNo: 1,
    list: [],
   
  },
  error: null,
  loading: false,
};
