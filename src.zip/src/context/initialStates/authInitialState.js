export default {
  isLoggedIn: false,
  data: {},
  error: null,
  loading: false,
};
