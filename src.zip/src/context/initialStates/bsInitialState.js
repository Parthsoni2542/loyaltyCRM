export default bsInitialState = {
  visible: false,
  canceledOnTouchOutside: true,
  body: null,
  index: 0,
  sindex: 0,
  lindex: 0,
};
