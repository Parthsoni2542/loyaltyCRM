export default bottomMsgIntialState = {
  messages: [],
};
