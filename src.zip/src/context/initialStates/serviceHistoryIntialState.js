export default {
    data: {
      hasMore: 1,
      pageNo: 1,
      list: [],
      bookbtn:true
     
    },
    error: null,
    loading: false,
  };
  