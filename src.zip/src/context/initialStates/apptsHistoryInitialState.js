export default {
  data: {
    hasMore: 1,
    history_appointment: [],
    pageNo: 1,
  },
  error: null,
  loading: false,
};
