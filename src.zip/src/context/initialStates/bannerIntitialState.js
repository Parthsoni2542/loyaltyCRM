export default {
    data:"",
    error: null,
    loading: false,
    visible:false
  };