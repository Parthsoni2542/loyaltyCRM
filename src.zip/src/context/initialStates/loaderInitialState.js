export default loaderInitialState = {
  counter: 0,
};
