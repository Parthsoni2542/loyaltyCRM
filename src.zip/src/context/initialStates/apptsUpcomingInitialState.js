export default {
  data: {
    hasMore: 1,
    upcoming_appointment: [],
    pageNo: 1,
  },
  error: null,
  loading: false,
};
